-- Beat Blend & Glow: owner dashboard permission hardening
-- Run once in Supabase SQL Editor after confirming the appointments table exists.
-- This allows the signed-in owner to change only the status of pending requests.
-- It does not open public booking or enable payments/notifications.

DROP POLICY IF EXISTS "Owner can update appointments" ON public.appointments;

CREATE POLICY "Owner can update pending appointment status"
ON public.appointments
FOR UPDATE
TO authenticated
USING (
  auth.uid() = owner_id
  AND status = 'pending'
)
WITH CHECK (
  auth.uid() = owner_id
  AND status IN ('approved', 'declined')
);

REVOKE UPDATE ON TABLE public.appointments FROM authenticated;
GRANT UPDATE (status) ON TABLE public.appointments TO authenticated;
