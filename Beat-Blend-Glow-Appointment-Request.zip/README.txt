BEAT BLEND & GLOW — APPOINTMENT REQUEST FORM UPDATE

WHAT THIS VERSION DOES
- Adds a pink, mobile-friendly appointment request form to index.html.
- Collects name, email, phone, service interest, preferred Saturday/Sunday date, preferred time and optional notes.
- Lists the proposed services and prices supplied by the owner.
- Restricts the preferred date to Saturday or Sunday in the browser.
- Sends submissions to Netlify Forms, where the site owner can review them in the Netlify dashboard.
- Shows thank-you.html after submission.
- Does not require Supabase or owner login for this request form.

IMPORTANT: REQUESTS ARE NOT CONFIRMED APPOINTMENTS
This is a request/interest workflow, not a live calendar. It does not reserve a time, prevent double-booking, approve appointments inside the owner dashboard, send email/push notifications, collect deposits, or process payments. Review submissions in Netlify Dashboard > your site > Forms. Contact a client separately if and when appointments can legally be offered.

LICENSING AND PRIVACY
The owner is a second-year cosmetology student working toward licensure. Do not offer or advertise independent cosmetology services or home appointments until applicable Virginia licensing and location requirements are satisfied. The form does not ask for a home address or payment details. Keep the private home address off the public website.

PUBLISH TO YOUR EXISTING NETLIFY SITE
1. Extract this ZIP in the iPhone Files app by tapping it once.
2. Open the extracted folder. It should contain index.html, owner.html, thank-you.html, owner-dashboard-hardening.sql and README.txt.
3. In Netlify, open the existing Beat Blend & Glow site (do not create a new site), then Deploys.
4. Upload the extracted site folder / folder contents containing index.html to the manual deploy area. Do not upload the ZIP if Netlify asks for a folder.
5. Wait for the production deploy to say Published.
6. Open the public website and scroll to “Request an appointment.” Submit one test request.
7. In Netlify Dashboard > your site > Forms, look for “appointment-request”. If it is not listed, check Site configuration > Forms and enable form detection, then redeploy.

OWNER LOGIN
owner.html is included unchanged from the previous prototype. Its Supabase login / appointment dashboard is not needed for this Netlify Forms request workflow and may still need separate configuration. Do not rely on it to review these form submissions.
